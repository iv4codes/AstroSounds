//
//  SpaceMusic.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 29.10.24.
//
import SwiftUI

struct SpaceMusic: View {
    @EnvironmentObject var tabManager: TabManager  // Access to the shared tab manager
    var body: some View {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color(red: 12/255, green: 16/255, blue: 53/255), Color.black]),
                    startPoint: .top, endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 50) {
                        Text("What does space sound like?")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .offset(y: -90)
Text("      Imagine translating the vastness of space into music - turning the positions of stars and galaxies into melodies! AstroSounds does just that. While space itself is silent (because there’s no air for sound to travel through), I am using real astronomical data—like Right Ascension (RA), Declination (Dec), and Distance - to generate unique, immersive soundscapes.")
                            .foregroundColor(.white)
                            .font(.system(size: 20))
                            .lineLimit(nil)
                            .padding(.horizontal, 15)
                            .offset(y: -130)
                        Text("How does it work?")
                            .foregroundColor(.white)
                            .font(.system(size: 30, weight: .bold))
                            .offset(y: -160)
                        Text("""
                             Each space object has coordinates that help astronomers locate it. Instead of just plotting them on a star map, I’m transforming these numbers into notes, rhythms, and harmonies! Here’s how:
                             🔹 Right Ascension (RA) → Tempo
                             RA determines how fast or slow the music plays. A lower RA creates a slow, deep tune, while a higher RA speeds things up.
                             🔹 Distance → Chord Progressions & Note Durations
                             The farther an object is, the more mysterious its harmony sounds. I’m mapping distances to different chord progressions, making some objects sound smooth and dreamy, while others feel eerie and distant.
                             🔹 Declination (Dec) → Pitch Adjustments
                             Dec subtly shifts the frequencies of the notes, giving each melody a unique signature - like a musical fingerprint of the cosmos.
                             🔹 Cosmic Effects
                             To make the music even more immersive, I’m adding reverb and delay as well, mimicking how sounds might “echo” in the vastness of space. Some deep - space objects also generate low, humming drone tones, creating an ambient cosmic atmosphere.
                        """)
                            .foregroundColor(.white)
                            .font(.system(size: 20))
                            .lineLimit(nil)
                            .padding(.horizontal, 15)
                            .offset(y: -180)
                        Text("💫 Want to hear how your favorite space object sounds?")
                            .foregroundColor(.white)
                            .font(.system(size: 30, weight: .bold))
                            .offset(y: -205)
                            .multilineTextAlignment(.center)
                        Text("Tap the button below to explore and listen to the universe in a whole new way! 🚀🎶")
                            .foregroundColor(.white)
                            .font(.system(size: 25, weight: .semibold))
                            .lineLimit(nil)
                            .padding(.horizontal, 15)
                            .multilineTextAlignment(.center)
                            .offset(y: -235)
                        // Explore Button
                        Button(action: {
                                        withAnimation {
                                            tabManager.selectedTab = 1
                                        }
                                    }) {
                            Text("Explore More")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.blue.opacity(0.8))
                                        .shadow(color: .blue, radius: 10)
                                )
                        }
                        .padding(.top, -260)
                    }
                   .padding(.top, 100)
                   .padding(.bottom, -150)
                }
                .navigationDestination(for: String.self) { value in
                                   if value == "ExplorePage" {
                                       ExplorepageUI()
                                   }
                                }
                            }
                        }
                    }

#Preview {
    SpaceMusic()
}
