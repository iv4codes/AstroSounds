//
//  SwiftUIView.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 30.01.25.
//

import SwiftUI

struct Learn: View {
    var body: some View {
            NavigationView{
                ZStack{
                    LinearGradient(gradient: Gradient(colors:[Color(red:12/255,green:16/255,blue:53/255),Color(.black)]),
                                   startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                    Image("constellationBackground")
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                        .opacity(0.15)
                        .toolbar {
                            ToolbarItem(placement: .topBarLeading) {
                                Text("Learning in Space")
                                    .font(.largeTitle)
                                    .padding(8)
                                    .padding(.bottom, 30)
                                    .cornerRadius(8)
                                    .offset(y: 15)
                                    .foregroundColor(.primary)
                                
                        }
                    }
                    ScrollView(showsIndicators: false) {
                        VStack {
                            LearnOptions()
                                .offset(y: 150)
                                .animation(.easeInOut(duration: 0.3), value: 150)
                        }
                        .padding(.bottom, 290)
                    }
                }
            }
        }
    }
struct LearnOptions: View{
    var body: some View{
        ZStack{
            NavigationLink(destination: StarsTempCol()) {
                ZStack(alignment: .bottomLeading) {
                    Image("orion-constellation")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 300, height: 400)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                    LinearGradient(
                        gradient: Gradient(colors: [Color.black.opacity(0.9), Color.black.opacity(0)]),
                        startPoint: .bottom,
                        endPoint: .top
                    )
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(
                        Text("Why are stars different colours?")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .multilineTextAlignment(.leading)
                            .foregroundColor(.white)
                            .padding()
                            .offset(y: -75)
                            .shadow(color: Color.black.opacity(1), radius: 3, x: 0, y: 2)
                        , alignment: .bottomLeading
                    )
                    .overlay(
                        Text("Tap here to discover how astronomers measure stars' temperatures!")
                            .font(.system(size: 20, weight: .light, design: .rounded))
                            .multilineTextAlignment(.leading)
                            .foregroundColor(.white)
                            .padding()
                        , alignment: .bottomLeading
                    )
                }
                .frame(width: 300, height: 200)
                .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 4)
            }
            .buttonStyle(PlainButtonStyle())
        }
        
        Spacer()
        ZStack{
            NavigationLink(destination: Exoplanet()) {
                ZStack(alignment: .bottomLeading) {
                    Image("Exoplanet")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 300, height: 400)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                    LinearGradient(
                        gradient: Gradient(colors: [Color.black.opacity(0.9), Color.black.opacity(0)]),
                        startPoint: .bottom,
                        endPoint: .top
                    )
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(
                        Text("How Do Gases Shape an Exoplanet’s Atmosphere?")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .multilineTextAlignment(.leading)
                            .foregroundColor(.white)
                            .padding()
                            .offset(y: -75)
                            .shadow(color: Color.black.opacity(1), radius: 3, x: 0, y: 2)
                        , alignment: .bottomLeading
                    )
                    .overlay(
                        Text("Tap here to see how they affect the planet’s color and spectral signature in real time!")
                            .font(.system(size: 20, weight: .light, design: .rounded))
                            .multilineTextAlignment(.leading)
                            .foregroundColor(.white)
                            .padding()
                        , alignment: .bottomLeading
                    )
                }
                .frame(width: 300, height: 200)
                .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 4)
                .padding(.top, 230)
                }
            .buttonStyle(PlainButtonStyle())
        }
        Spacer()
        NavigationLink(destination: SpaceMusic()) {
            ZStack(alignment: .bottomLeading) {
                Image("spacemusic")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 300, height: 400)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                LinearGradient(
                    gradient: Gradient(colors: [Color.black.opacity(0.9), Color.black.opacity(0)]),
                    startPoint: .bottom,
                    endPoint: .top
                )
                .frame(height: 200)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .overlay(
                    Text("What does space sound like?")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                        .padding()
                        .offset(y: -75)
                        .shadow(color: Color.black.opacity(1), radius: 3, x: 0, y: 2)
                    , alignment: .bottomLeading
                )
                .overlay(
                    Text("Tap here to learn more about the process of translating space coordinates to music.")
                        .font(.system(size: 20, weight: .light, design: .rounded))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                        .padding()
                    , alignment: .bottomLeading
                )
            }
            .frame(width: 300, height: 200)
            .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 4) 
            .padding(.top, 230)
        }
        .buttonStyle(PlainButtonStyle())
    }
}


#Preview {
    Learn()
}

