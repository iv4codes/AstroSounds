//
//  TabView.swift
//  AstroSounds4
//
//  Created by Ivayla Dimitrova on 23.10.24.
//

import SwiftUI

struct CustomTabView: View {
    var screenWidth: CGFloat
    var screenHeight: CGFloat
    @StateObject var tabManager = TabManager()
    init(){
        screenWidth = UIScreen.main.bounds.width
        screenHeight = UIScreen.main.bounds.height
        UITabBar.appearance().backgroundColor = UIColor.systemGray6
    }
    var body: some View {
        
        TabView(selection: $tabManager.selectedTab) {
            LearnView()
                .tabItem{
                    Image(systemName: "moon.stars")
                    Text ("Learn more")
                }
                .tag(0)
            ExploreView()
                .tabItem{
                    Image(systemName: "magnifyingglass")
                    Text ("Explore")
                }
                .tag(1)
        }
        .environmentObject(tabManager) // Shares the tab manager
        .accentColor(.black)
    }
}
struct ExploreView:View{
    var body:some View{
        ExplorepageUI()
    }
}
struct LearnView: View {
    var body: some View {
        Learn()
    }
}


#Preview {
    CustomTabView()
}


