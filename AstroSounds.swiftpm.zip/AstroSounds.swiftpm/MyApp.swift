//
//  AstroSoundsApp.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 29.10.24.
//
import SwiftUI

@main
struct AstroSoundsApp: App {
    var body: some Scene {
        WindowGroup {
            CustomTabView()
                .preferredColorScheme(.dark)
        }
    }
}
