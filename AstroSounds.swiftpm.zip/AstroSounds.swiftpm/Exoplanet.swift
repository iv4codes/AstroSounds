//
//  Exoplanet.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 29.10.24.
//
import SwiftUI
import RealityKit
@preconcurrency import ARKit

struct Exoplanet: View {
    @State private var selectedGases: [String] = []
    @State private var textPrompt: String? = nil
    @State private var showPopups = true
    
    var body: some View {
        ZStack{
            ZStack {
                ARViewContainerDE(selectedGases: $selectedGases)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Spacer()
                    
                    SpectrogramView(selectedGases: $selectedGases)
                        .frame(height: 60)
                        .background(Color.white.opacity(0.8))
                    
                    GasSelectionView(selectedGases: $selectedGases, textPrompt: $textPrompt)
                    if let textPrompt = textPrompt {
                        Text(textPrompt)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                            .padding()
                            .background(Color.white.opacity(0.9))
                            .cornerRadius(15)
                            .shadow(radius: 10)
                            .transition(.opacity)
                            .animation(.easeInOut, value: textPrompt)
                            .padding(.bottom, 40)
                    }
                }
            }
            .blur(radius: showPopups ? 10 : 0) // Blurs AR when popups are active
            .animation(.easeInOut(duration: 0.3), value: showPopups)
            if showPopups {
                ExoplanetLearningPopups(showPopups: $showPopups)
            }
            
        }
    }
}

struct ARViewContainerDE: UIViewRepresentable {
    @Binding var selectedGases: [String]
    @State private var textPrompt: String? = nil 

    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView(frame: .zero)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        arView.session.run(configuration)
        if let cameraNode = arView.pointOfView {
            cameraNode.eulerAngles.y += Float.pi
            cameraNode.position.z -= 2
        }
        
        let anchor = ARAnchor(transform: simd_float4x4(1))
        arView.session.add(anchor: anchor)
        
        let planet = SCNNode(geometry: SCNSphere(radius: 0.1))
        planet.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "star_texture")
        planet.position = SCNVector3(0, 0, -2)
        arView.scene.rootNode.addChildNode(planet)
        
        let star = SCNNode(geometry: SCNSphere(radius: 0.05))
        star.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "exoplanet_texture")
        let orbitRadius: Float = 0.5
        let orbitEntity = SCNNode()
        context.coordinator.starNode = star
        
        orbitEntity.position = planet.position
        orbitEntity.addChildNode(star)
        arView.scene.rootNode.addChildNode(orbitEntity)
        // Star orbit animation
        startOrbitAnimation(orbitEntity, orbitRadius, planetPosition: planet.position)
        createSpaceDome(arView)
        // Checks planet's position and dims star accordingly
        let cameraNode = arView.pointOfView
        if let cameraNode = cameraNode {
            arView.scene.rootNode.addChildNode(cameraNode)
            
            Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { _ in
                DispatchQueue.main.async {
                    let isStarInFront = isStarInFrontOfPlanet(star, planet, cameraNode)
                    dimPlanetIfStarInFront(isStarInFront, planet)
                }
            }
        }
        
        return arView
        
    }
    func updateUIView(_ uiView: ARSCNView, context: Context) {
        let newColor = calculateStarColor(selectedGases: selectedGases)
        let starMaterial = context.coordinator.starNode?.geometry?.firstMaterial
        starMaterial?.diffuse.contents = UIImage(named: "exoplanet_texture")
        starMaterial?.multiply.contents = newColor
    }
    func createSpaceDome(_ arView: ARSCNView) {
        let domeGeometry = SCNSphere(radius: 200)
        let domeMaterial = SCNMaterial()
        domeMaterial.diffuse.contents = UIImage(named: "foreign_planet3")
        domeMaterial.isDoubleSided = true
        domeGeometry.materials = [domeMaterial]
        let domeNode = SCNNode(geometry: domeGeometry)
        domeNode.position = SCNVector3(0, 0, 0)
        arView.scene.rootNode.addChildNode(domeNode)
        domeNode.rotation = SCNVector4(0, 1, 0, Double.pi)
        // Adds lighting
        let light = SCNLight()
        let lightNode = SCNNode()
        lightNode.light = light
        lightNode.position = SCNVector3(x: 0, y: 100, z: 100)
        arView.scene.rootNode.addChildNode(lightNode)
    }
    func startOrbitAnimation(_ orbitEntity: SCNNode, _ orbitRadius: Float, planetPosition: SCNVector3) {
        var angle: Float = 0.0
        let speed: Float = 0.01 // Orbital speed
        
        Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { _ in
            angle += speed
            let x = planetPosition.x + orbitRadius * cos(angle)
            let z = planetPosition.z + orbitRadius * sin(angle)
            orbitEntity.position = SCNVector3(x, orbitEntity.position.y, z)
        }
    }
    //Checks if the star is in front of the planet
    func isStarInFrontOfPlanet(_ star: SCNNode, _ planet: SCNNode, _ cameraNode: SCNNode) -> Bool {
        let planetPosition = planet.presentation.worldPosition
        let starPosition = star.presentation.worldPosition
        let cameraPosition = cameraNode.presentation.worldPosition
        let planetToStar = SCNVector3(starPosition.x - planetPosition.x, starPosition.y - planetPosition.y, starPosition.z - planetPosition.z)  // Performs vector subtraction to calculate direction vectors
        let planetToCamera = SCNVector3(cameraPosition.x - planetPosition.x, cameraPosition.y - planetPosition.y, cameraPosition.z - planetPosition.z)
        let dotProduct = planetToCamera.x * planetToStar.x + planetToCamera.y * planetToStar.y + planetToCamera.z * planetToStar.z         // Calculates the dot product between the two vectors
        return dotProduct > 0
    }
    func dimPlanetIfStarInFront(_ isStarInFront: Bool, _ planet: SCNNode) {   //Dims the planet's opacity if the star is in front of it
        let targetOpacity: CGFloat = isStarInFront ? 0.3 : 1.0   // Checks if the planet is visible or not based on star position
        let opacityAction = SCNAction.fadeOpacity(to: targetOpacity, duration: 0.5)
        planet.runAction(opacityAction)
    }
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
    class Coordinator {
        var starNode: SCNNode?
    }
    private func calculateStarColor(selectedGases: [String]) -> UIColor {
        let gasToHue: [String: CGFloat] = [
            "Oxygen": 210.0,        // Pale blue
            "Carbon Dioxide": 45.0, // Yellowish/Brownish
            "Methane": 240.0        // Blue
        ]
        let hues = selectedGases.compactMap { gasToHue[$0] }
        let averageHue = hues.isEmpty ? 180.0 : hues.reduce(0, +) / CGFloat(hues.count)
        return UIColor(hue: averageHue / 360.0, saturation: 0.8, brightness: 0.8, alpha: 1.0)
    }
}
struct GasSelectionView: View {
    @Binding var selectedGases: [String]
    @Binding var textPrompt: String?

    let gases = ["Oxygen", "Carbon Dioxide", "Methane"]
    
    var body: some View {
        HStack {
            ForEach(gases, id: \.self) { gas in
                Button(action: {
                    toggleGas(gas)
                }) {
                    Text(gas)
                        .padding()
                        .background(selectedGases.contains(gas) ? Color.blue : Color.gray)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
            }
        }
        .padding()
    }
    private func toggleGas(_ gas: String) {
        if selectedGases.contains(gas) {
            selectedGases.removeAll { $0 == gas }
        } else {
            selectedGases.append(gas)
        }
        checkGasCombination()
    }
    private func checkGasCombination() {
            let combinations: [Set<String>: String] = [
                ["Oxygen", "Methane"]: "🔥 Alien life detected! Oxygen and Methane make a strong case! 🛸",
                ["Carbon Dioxide", "Methane"]: "🌫️ A greenhouse effect is brewing! Could this exoplanet be warming up? ☀️",
                ["Oxygen", "Carbon Dioxide"]: "🍃 A breathable atmosphere? Life might be possible! 🌎"
            ]
            
            for (combo, message) in combinations {
                if combo.isSubset(of: Set(selectedGases)) {
                    textPrompt = message
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        withAnimation {
                            textPrompt = nil
                        }
                    }
                    return
                }
            }
            textPrompt = nil
        }
}
struct SpectrogramView: View {
    @Binding var selectedGases: [String]
    
    let baseSpectrogram = "spectral_lines"
    
    let absorptionLines: [String: [CGFloat]] = [
        "Oxygen": [687, 760],
        "Carbon Dioxide": [1400, 1600, 2000],
        "Methane": [1660, 2200]
    ]
    
    var body: some View {
        ZStack {
            Image(baseSpectrogram)
                .resizable()
                .scaledToFit()
            
            ForEach(selectedGases, id: \.self) { gas in
                if let positions = absorptionLines[gas] {
                    ForEach(positions, id: \.self) { position in
                        Rectangle()
                            .fill(Color.black)
                            .frame(width: 2, height: 29)
                            .offset(x: scaleToSpectrogram(position))
                    }
                }
            }
        }
    }
    func scaleToSpectrogram(_ wavelength: CGFloat) -> CGFloat {
        let minWavelength: CGFloat = 400   // Start of visible spectrum
        let maxWavelength: CGFloat = 2200  // Near-infrared end
        let spectrogramWidth: CGFloat = 500
        
        return ((wavelength - minWavelength) / (maxWavelength - minWavelength)) * spectrogramWidth - spectrogramWidth / 2
    }
}
struct ExoplanetLearningPopups: View {
    @Binding var showPopups: Bool
    @State private var currentPopupIndex = 0
    
    let popups: [(text: String, buttonText: String)] = [
        ("🌍 Ready to explore a distant exoplanet? See how its atmosphere transforms when you add different gases. Tap below to begin your journey.", "Start exploring ➡️"),
        ("🔬 Spectrogram and Absorption Lines\n\nA spectrogram shows how light is absorbed by the exoplanet’s atmosphere. Different gases absorb light at specific wavelengths, creating absorption lines. These lines help scientists identify which gases are present in the atmosphere.", "Got it! ➡️"),
          ("💨 Adding Gases\n\nWatch as the exoplanet’s spectrogram updates in real time when you add gases to its atmosphere. Each gas creates an absorption line (seen at the bottom) and shifts the planet’s color. For instance, methane may turn the atmosphere green, while carbon dioxide could make it red!", "Next ➡️"),
          ("🌈 Atmospheric Effects\n\nGases absorb different wavelengths of light, shaping the planet’s color. The mix of gases gives the planet its unique appearance. Experiment to uncover how different combinations change the exoplanet!", "Next ➡️"),
          ("📚 Learn as You Go\n\nEach time you add a gas, a pop-up will explain how it affects the atmosphere and color. Let’s see the science behind your combinations!", "Next ➡️"),
          ("🚀 Time to Create Your Own Exoplanet! You’re now observing a distant exoplanet and its star from another planet. Try adding different gases and watch how both the planet and its spectrogram change. Enjoy experimenting!", "Let's make an exoplanet! 🌎")
    ]
    
    var body: some View {
        VStack {
            Text(popups[currentPopupIndex].text)
                .font(.system(size: 18, weight: .medium))
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                .padding()
            
            Button(action: {
                if currentPopupIndex < popups.count - 1 {
                    currentPopupIndex += 1
                } else {
                    withAnimation {
                        showPopups = false
                    }
                }
            }) {
                Text(popups[currentPopupIndex].buttonText)
                    .font(.headline)
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.purple)
                    .cornerRadius(10)
            }
            .padding(.top, 10)
        }
        .padding()
        .frame(width: 300)
        .background(Color.white.opacity(0.9))
        .cornerRadius(15)
        .shadow(radius: 5)
    }
}
struct OrbitingStarView_Previews: PreviewProvider {
    static var previews: some View {
        Exoplanet()
    }
}
