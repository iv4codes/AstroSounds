//
//  ExplorepageUI.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 29.10.24.
//

import SwiftUI
@preconcurrency import AVFoundation
import Foundation
import AudioKit

func applyReverb(to audioEngine: AVAudioEngine) {
    let reverb = AVAudioUnitReverb()
    reverb.loadFactoryPreset(.largeRoom) // Using a large room preset for spaciousness
    reverb.wetDryMix = 50 // 50% reverb effect to blend it nicely with the dry sound
    audioEngine.attach(reverb)
    audioEngine.connect(audioEngine.mainMixerNode, to: reverb, format: nil)
    audioEngine.connect(reverb, to: audioEngine.outputNode, format: nil)
}

    struct Card: Identifiable {
        let id = UUID()
        let heading: String
        let description: String
        let imageName: String
        let detailDescription: String
        let imageCredit: String
        let ra: Double
        let dec: Double
        let distance: Double
    }
struct ExplorepageUI: View {
    @State private var selectedCard: Card?
    private let musicPlayer = MusicPlayer()
    @State private var isPlaying = false
    @State private var progress: Double = 0.0
    @State private var showMore = false
    @State private var currentIndex = 0
    @State private var currentCards: [Card] = []
    let galaxies = [
        Card(heading: "The Mice Galaxies",
             description: "You can tap on each object's card to see more information about it and hear its sound.",
             imageName: "TheMiceGalaxiesHubble",
             detailDescription:"""
                            These galaxies get their name from the long tails shaped by galactic tides—gravitational forces pulling on each galaxy. Likely involved in a past collision, they may continue merging over time. NGC 4676A has a bluish-white remnant of spiral arms surrounding a core with dark markings, while its tail transitions from blue to yellow, an unusual color pattern. NGC 4676B has a yellowish core with bluish arm remnants. They’re located about 300 million light-years away in the constellation Coma Berenices. Captured by Hubble in 2002, over 3,000 distant galaxies are visible in the background, some up to 13 billion light-years away.
                        """,
             imageCredit: "Image Credit: NASA, H. Ford (JHU), G. Illingworth (UCSC/LO), M. Clampin (STScI), G. Hartig (STScI), the ACS Science Team, and ESA",
             ra: 191.295,
             dec: 27.531,
             distance: 300000000
             
),
             Card(heading: "Arp 140",
             description: "A pair of interacting galaxies. The left galaxy is known as NGC 275, and the right galaxy NGC 274.",
             imageName: "Arp140NASA",
             detailDescription:"""
    NGC 274 is a lenticular galaxy in Cetus, interacting with its companion, NGC 275. Discovered by William Herschel in 1785, it lies about 120 million light-years away. NGC 275, a barred spiral galaxy roughly 63 million light-years from Earth, was noted in the New General Catalogue as “very faint, small, round, southeastern of 2” by John Dreyer. 
""",
                  imageCredit: "Image Credit: NASA/ESA/R. Foley (University of California – Santa Cruz)/Processing: Gladys Kober (NASA/Catholic University of America)",
                  ra: 114,
                  dec: 19.850,
                  distance: 100000000
                 )
    ]
    
    let stars = [
        Card(heading: "RS Puppis",
             description: "It is a glittering star 200 times larger than our Sun and wreathed with dust reflecting starlight.",
             imageName: "RSPuppis",
             detailDescription:"""
    RS Puppis is a Cepheid variable star about 6,000 light-years away in Puppis. One of the largest and brightest Cepheids in the Milky Way, it has a long pulsation period of 41.5 days. Its brightness varies from magnitude 6.52 to 7.67 as it expands and contracts. Since Cepheids are key distance markers, RS Puppis plays an important role in measuring cosmic distances.
""",
             imageCredit: "Image Credit: NASA, ESA, and the Hubble Heritage Team (STScI/AURA)-Hubble/Europe Collaboration",
             ra: 131.205,
             dec: -22.121,
             distance: 6500
        )]
    let nebulae = [
        Card(heading: "Cat's Eye Nebula",
             description: "Spectacular structure formed by blowing off huge clouds of gas and dust",
             imageName: "Cat's Eye Nebula",
             detailDescription:"""
    Also known as Caldwell 6, this planetary nebula in Draco was discovered by William Herschel. It has a bright inner nebula spanning 16.1 arcseconds and outer condensations reaching 25 arcseconds. Deep images reveal an extended halo about 5 arcminutes wide, once ejected by the central star in its red giant phase.
""",
             imageCredit: "Image Credit: Hubble Space Telescope",
             ra: 269.639,
             dec: 66.617,
             distance: 3000
    )
    ]
    let starclusters = [
        Card(heading:"Pismis 24",
             description: "Pismis 24 is a stunning star cluster that lies within the nebula NGC 6357.",
             imageName: "Pismis 24",
             detailDescription:"""
   The star cluster Pismis 24 lies within NGC 6357, an emission nebula 8,000 light-years away. Its gas glows due to ultraviolet radiation from young, massive stars, whose intense energy pushes the surrounding material outward, forming low-density bubbles. Pismis 24-1, once a top contender for the title of “Milky Way Stellar Heavyweight Champion,” shines at the cluster’s core.
""",
             imageCredit: "Image Credit: NASA, ESA and Jesús Maíz Apellániz (Instituto de Astrofísica de Andalucía, Spain",
             ra: 261,
             dec: -33.217,
             distance: 8000
            )
    ]
    let supernovas = [
        Card(heading:"Supernova 1987A",
             description: "One of the brightest supernova explosions in centuries",
             imageName: "Supernova 1987A",
             detailDescription:"""
    SN 1987A, a Type II supernova in the Large Magellanic Cloud, was the closest observed supernova since 1604. Light and neutrinos from the explosion reached Earth on February 23, 1987, with its brightness peaking in May at an apparent magnitude of 3. It was the first supernova extensively studied with modern technology, confirming the radioactive source of its post-explosion glow. In 2019, indirect evidence suggested a collapsed neutron star within its remnants.
""",
             imageCredit: "Image Credit: James Webb Space Telescope",
             ra: 84.865,
             dec: -68.730,
             distance: 168000
            )
    ]
    let blackholes = [
        Card(heading:"Black Hole at the Center of Galaxy M87",
             description: "It is about 55 light years away from us.",
             imageName: "Black Hole at the Center of Galaxy M87",
             detailDescription:"""
   The supermassive black hole at the center of M87, located 55 million light-years away, was imaged by the Event Horizon Telescope in 2019. Its mass was measured at 6.5 billion solar masses. A rotating disk of ionized gas surrounds it, moving at speeds up to 1,000 km/s, and spans a maximum diameter of 25,000 AU.
""",
             imageCredit: "Image Credit: Event Horizon Telescope (EHT)",
             ra: 187.706,
             dec: 12.391,
             distance: 55000000
            )
    ]
    let galaxyclusters = [
        Card(heading:"Bullet Cluster",
             description: "This image of the Bullet Cluster provided the first direct proof of dark matter.",
             imageName: "Bullet Cluster",
             detailDescription:"""
   The Bullet Cluster consists of two colliding galaxy clusters, with the smaller subcluster moving away. Located 3.72 billion light-years away, it is a key piece of evidence for dark matter due to gravitational lensing studies.
""",
             imageCredit: "Image Credit: X-ray: NASA/CXC/CfA/M.Markevitch, Optical and lensing map: NASA/STScI, Magellan/U.Arizona/D.Clowe, Lensing map: ESO WFI",
             ra: 164.498,
             dec: -54.050,
             distance: 3800000000000
            ),
        Card(heading: "Hoag's Object",
             description: "It is slightly larger than our own home galaxy, the Milky Way!",
             imageName: "Hoag's Object (Ring galaxy)",
             detailDescription:"""
    Hoag’s Object is a rare ring galaxy in Serpens Caput, discovered by Arthur Hoag in 1950. A near-perfect ring of young blue stars surrounds an older yellow core, located 600 million light-years away. Its inner core is about 17,000 light-years in diameter, while the outer ring spans up to 121,000 light-years. It has an estimated mass of 700 billion suns.
""",
             imageCredit: "Image Credit: NASA and The Hubble Heritage Team (STScI/AURA)",
             ra: 210,
             dec: 18.050,
             distance: 600000000
            )
    ]
    let globularclusters = [
        Card(heading: "Caldwell 73 Small",
             description: "Caldwell 73 may be a remnant of two clusters that collided within a dwarf galaxy that once hosted them both.",
             imageName: "Caldwell 73 Small",
             detailDescription:"""
   Caldwell 73 (NGC 1851) is a dense globular cluster about 40,000 light-years away in Columba, discovered in 1826. It has an apparent magnitude of 7.3 and is visible through binoculars. Unlike most globular clusters, it contains stars of different ages and is surrounded by a diffuse halo. One theory suggests it formed from the merger of two clusters within a now-disrupted dwarf galaxy.
""",
             imageCredit: "Image Credit: Hubble Space Telescope",
             ra: 316.043,
             dec: -10.650,
             distance: 2900
            ),
    ]
    
    var body: some View {
        NavigationView{
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 12/255, green: 16/255, blue: 53/255),
                        Color.black
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                Image("constellationBackground")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.15)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Text("Explore")
                                .font(.largeTitle)
                                .padding(8)
                                .padding(.bottom, 30)
                                .cornerRadius(8)
                                .offset(y: 15)
                                .foregroundColor(.primary)
                        }
                    }
                VStack{
                    ScrollView(.horizontal, showsIndicators: false){
                        HStack {
                            Button("Galaxies") {
                                withAnimation {
                                    currentCards = galaxies
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            Button("Stars") {
                                withAnimation {
                                    currentCards = stars
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Star clusters") {
                                withAnimation {
                                    currentCards = starclusters
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Nebulae") {
                                withAnimation {
                                    currentCards = nebulae
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Supernovas") {
                                withAnimation {
                                    currentCards = supernovas
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Black holes") {
                                withAnimation {
                                    currentCards = blackholes
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Galaxy clusters") {
                                withAnimation {
                                    currentCards = galaxyclusters
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            
                            Button("Globular clusters") {
                                withAnimation {
                                    currentCards = globularclusters
                                    currentIndex = 0
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                        }
                     .padding(.top, 80)
                    }
                    .padding(.leading, 45)
                    .padding(.trailing, 10)
                    
                    
                    TabView(selection: $currentIndex) {
                        ForEach(currentCards.indices, id: \.self) { index in
                            CardView1(card: currentCards[index])
                                .frame(width: 300, height: 400)
                                .background(Color.white)
                                .cornerRadius(10)
                                .padding()
                                .onTapGesture {
                                    selectedCard = currentCards[index]
                                }
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .onChange(of: currentIndex) { newIndex in
                    }

                    HStack(spacing: 8) {
                        ForEach(0..<currentCards.count, id: \.self) { index in
                            Circle()
                                .fill(index == currentIndex ? Color.white : Color.gray)
                                .frame(width: 8, height: 8)
                        }
                    }
                    .offset(y: -65)
                }
                .sheet(item: $selectedCard) {card in
                    CardDetailView(
                           card: card
                    )
                }
            }
            .onAppear {
                currentCards = galaxies
            }
        }
    }
}
    
    struct CardView1: View {
        let card: Card
        
        var body: some View {
            VStack(spacing: 10) {
                Image(card.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(10)
                    Text(card.heading)
                        .font(.headline)
                        .foregroundColor(.black)
                    
                    Text(card.description)
                        .font(.body)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding()
            }
        }
    }
struct CardDetailView: View {
    let card: Card
    @State private var progress: Double = 0
    @State private var currentTimeFormatted: String = "00:00"
    @State private var totalDurationFormatted: String = "00:00"
    private let musicPlayer = MusicPlayer()
    @State private var isPlaying = false
    @State private var isSaved: Bool = false
    @State private var audioFileURL: URL?
    @State private var hasStopped = false
    var body: some View{
        ScrollView{
            VStack(alignment: .center){
                Image(card.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
                
                Text(card.heading)
                    .font(.largeTitle)
                    .padding()
                    .padding(.leading, 20)
                    .padding(.trailing, 20)
                Text(card.description)
                    .font(.body)
                    .padding(.top, -20)
                    .multilineTextAlignment(.center)
                VStack{
                    Slider (
                        value: $progress,
                        in: 0...100,
                        step: 1
                    )
                    .frame(width: 350)
                    .disabled(true)
                    .onChange(of: progress) { newValue in
                            musicPlayer.currentTime1 = musicPlayer.totalDuration1 * newValue / 100
                        }
                    .onAppear {
                        progress = (musicPlayer.currentTime1 / musicPlayer.totalDuration1) * 100
                    }
                    HStack{
                        Button(action: {
                            if isPlaying {
                                musicPlayer.stop()
                                isPlaying = false
                                hasStopped = true // Prevents further play
                            } else if !hasStopped {
                                musicPlayer.generateFullPiece(for: card.ra, dec: card.dec, distance: card.distance, card: card)
                                musicPlayer.startTimer(progress: $progress) { newProgress in
                                    progress = newProgress
                                }
                                isPlaying = true
                            }
                        }) {
                            Image(systemName: isPlaying ? "stop.circle.fill" : "play.circle.fill")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundColor(hasStopped ? .gray : .blue)
                        }
                        .disabled(hasStopped) // Disables button after stopping
                    }
                }
                    Text(card.detailDescription)
                        .font(.body)
                        .padding()
                        .padding(.leading, 10)
                Text(card.imageCredit)
                    .font(.body)
                    .padding()
                    .fontWeight(.light)
                    .padding(.leading, 10)
                }
                .onDisappear{
                    musicPlayer.pause()
                }
            }
    
            .padding(.top, 20)
        }
    }
class MusicPlayer {
    private var audioEngine: AVAudioEngine?
    private var sampler: AVAudioUnitSampler?
    private var progressTimer: Timer?
    private var currentTime: Double = 0
    private var totalDuration: Double = 0
    private var isPaused = false
    private var currentTimeFormatted: String = "00:00"
    private var totalDurationFormatted: String = "00:00"
    private var internalCurrentTime: Double = 0
       private var internalTotalDuration: Double = 0
    private var audioFile: AVAudioFile?
       private var audioFormat: AVAudioFormat?

       var currentTime1: Double {
           get { return internalCurrentTime }
           set { internalCurrentTime = newValue }
       }

       var totalDuration1: Double {
           get { return internalTotalDuration }
           set { internalTotalDuration = newValue }
       }
    func startTimer(progress: Binding<Double>, progressUpdate: @escaping (Double) -> Void) {
            progressTimer?.invalidate()
            progressTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                if self.currentTime < self.totalDuration {
                    self.currentTime += 1
                    self.updateTimeFormatted()
                    let progressValue = (self.currentTime / self.totalDuration) * 100
                    progressUpdate(progressValue)
                } else {
                    self.progressTimer?.invalidate()
                    self.isPaused = true
                }
            }
        }

        func updateTimeFormatted() {
            let currentMinutes = Int(currentTime) / 60
            let currentSeconds = Int(currentTime) % 60
            currentTimeFormatted = String(format: "%02d:%02d", currentMinutes, currentSeconds)

            let totalMinutes = Int(totalDuration) / 60
            let totalSeconds = Int(totalDuration) % 60
            totalDurationFormatted = String(format: "%02d:%02d", totalMinutes, totalSeconds)
        }

    func updateProgress(progressBinding: Binding<Double>) {
           if totalDuration > 0 {
               let progress = (currentTime / totalDuration) * 100
               progressBinding.wrappedValue = progress
           }
       }
   //Chord progressions
    private let chordProgression: [[Double]] = [
        [0, 4, 7],   // C major chord
        [2, 5, 9],   // D minor chord
        [4, 7, 11],  // E minor chord
        [5, 9, 12]   // F major chord
    ]
    func stopTimer() {
        progressTimer?.invalidate()
        progressTimer = nil
    }

    func resetTimer() {
        currentTime = 0
        totalDuration = 0
    }

    func distanceToChord(distance: Double) -> [Double] {
        let index = Int(distance.truncatingRemainder(dividingBy: Double(chordProgression.count)))
        return chordProgression[index]
    }

    func distanceToDuration(distance: Double) -> Double {
        let maxDistance: Double = 10000
        return max(0.1, min(2.0, distance / maxDistance))
    }

    func raToTempo(ra: Double) -> Double {
        return 60 + (ra.truncatingRemainder(dividingBy: 5.0) * 10) // Tempo between 60-100 bpm
    }
    func generateMelody(for ra: Double, dec: Double, distance: Double) -> [(frequency: Double, duration: Double)] {
        var melody: [(frequency: Double, duration: Double)] = []
        let baseOffset = (ra + dec + distance).truncatingRemainder(dividingBy: 7.0)
        for _ in 0..<15 {
            let randomStep = Double.random(in: 0..<6)
            let adjustedDistance = distance + randomStep * 300.0
            let chord = distanceToChord(distance: adjustedDistance).map { pitch in
                pitch + ra.truncatingRemainder(dividingBy: 12.0) + dec.truncatingRemainder(dividingBy: 8.0) - baseOffset
            }
            let frequencies = chord.map { pitchToFrequency(pitch: $0) }
            let duration = max(0.5, min(4.0, distanceToDuration(distance: adjustedDistance) + Double.random(in: 0..<1.0)))
            for frequency in frequencies {
                melody.append((frequency: frequency, duration: duration))
            }
        }
        return melody
    }
    func generateFullPiece(for ra: Double, dec: Double, distance: Double, card: Card) {
        let melody = generateMelody(for: ra, dec: dec, distance: distance)
        let tempo = raToTempo(ra: ra) // Uses the card's RA for tempo
        totalDuration = melody.reduce(0) { $0 + $1.duration } // Calculates total duration
        playMelody(melody: melody, tempo: tempo)
    }
    func playMelody(melody: [(frequency: Double, duration: Double)], tempo: Double) {
        audioEngine = AVAudioEngine()
        sampler = AVAudioUnitSampler()
        
        guard let audioEngine = audioEngine, let sampler = sampler else { return }

        let reverb = AVAudioUnitReverb()
        reverb.loadFactoryPreset(.largeHall)
        reverb.wetDryMix = 50
        let delay = AVAudioUnitDelay()
        delay.delayTime = 0.3

        audioEngine.attach(sampler)
        audioEngine.attach(reverb)
        audioEngine.attach(delay)
        audioEngine.connect(sampler, to: delay, format: nil)
        audioEngine.connect(delay, to: reverb, format: nil)
        audioEngine.connect(reverb, to: audioEngine.mainMixerNode, format: nil)

        do {
            try audioEngine.start()
        } catch {
            print("Audio Engine failed to start: \(error)")
            return
        }

        DispatchQueue.global().async {
            for note in melody {
                self.playFrequency(frequency: note.frequency, duration: note.duration)
                Thread.sleep(forTimeInterval: note.duration)
            }
        }
    }
    func playFrequency(frequency: Double, duration: Double) {
        guard let sampler = sampler else { return }
        // Adding multiple harmonics (or stacked frequencies)
        let harmonics: [Double] = [frequency, frequency * 2.0, frequency * 3.0] // Octave and fifth
        for harmonic in harmonics {
            let midiNote = frequencyToMIDINote(frequency: harmonic)
            sampler.startNote(UInt8(midiNote), withVelocity: 64, onChannel: 0)
        }
        DispatchQueue.global().asyncAfter(deadline: .now() + duration) {
            for harmonic in harmonics {
                let midiNote = self.frequencyToMIDINote(frequency: harmonic)
                self.sampler?.stopNote(UInt8(midiNote), onChannel: 0)
            }
        }
    }
        func pause() {
            isPaused = true
            progressTimer?.invalidate()
            audioEngine?.pause()
        }
    func stop() {
        progressTimer?.invalidate()
        
        if let engine = audioEngine {
            engine.stop()
            engine.reset()
            engine.detach(sampler!)
        }
        
        audioEngine = nil
        sampler = nil
        currentTime = 0
    }
    
    // Helper functions
    func applyVibrato(to frequency: Double, intensity: Double) -> Double {
        // Slight vibrato effect by modulating the frequency
        let vibrato = sin(2 * .pi * frequency * 0.1) * intensity // Slow vibrato
        return frequency + vibrato
    }
    
    func generateDrone(for ra: Double, dec: Double, distance: Double) -> [(frequency: Double, duration: Double)] {
        var drone: [(frequency: Double, duration: Double)] = []
        let droneFrequency = pitchToFrequency(pitch: ra + dec) * 0.3 // Low, cosmic drone
        let droneDuration = max(5.0, min(10.0, distanceToDuration(distance: distance) * 2.0)) // Long-lasting drone
        drone.append((frequency: droneFrequency, duration: droneDuration))
        
        return drone
    }
    
    func pitchToFrequency(pitch: Double) -> Double {
        let baseFrequency = 440.0 * pow(2.0, pitch / 12.0)
        return baseFrequency * 0.5 // Lowers the pitch
    }
    func frequencyToMIDINote(frequency: Double) -> Int {
        return Int(round(69 + 12 * log2(frequency / 440.0))) // Converts frequency to MIDI note
    }
    func playGeneratedAudio() {
        let melody = generateMelody(for: 0.0, dec: 0.0, distance: 0.0)
        let tempo = 120.0
        playMelody(melody: melody, tempo: tempo) 
    }
    struct Sound: Identifiable, Codable {
        var id = UUID()
        var name: String
        var fileName: String
    }
}
#Preview {
    ExplorepageUI()
}

