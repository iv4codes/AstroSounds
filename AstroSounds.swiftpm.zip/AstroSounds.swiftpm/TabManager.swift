//
//  TabManager.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 7.02.25.
//

import SwiftUI

class TabManager: ObservableObject {
    @Published var selectedTab: Int = 0
}
