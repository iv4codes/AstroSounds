//
//  ContentView.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 23.10.24.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
    }
}
