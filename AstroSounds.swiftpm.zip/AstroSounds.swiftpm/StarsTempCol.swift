//
//  StarsTempCol.swift
//  AstroSounds
//
//  Created by Ivayla Dimitrova on 31.01.25.
//

import SwiftUI
import ARKit
import SceneKit

struct StarsTempCol: View {
    @State private var temperature: Float = 5780
    @State private var showPopups = true

    var body: some View {
        ZStack {
            ARViewContainer(temperature: $temperature)
                .edgesIgnoringSafeArea(.all)
                .blur(radius: showPopups ? 10 : 0) // Blurs AR when popups are active
                .animation(.easeInOut(duration: 0.3), value: showPopups)

            if showPopups {
                StarLearningPopups(showPopups: $showPopups)
            }

            VStack {
                Spacer()
                Slider(value: $temperature, in: 3000...10000, step: 100)
                    .padding()
                    .accentColor(.white)

                Text("Temperature: \(Int(temperature)) K")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding(.bottom, 20)
            }
        }
    }
}
struct ARViewContainer: UIViewRepresentable {
    @Binding var temperature: Float
    
    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView()
        let configuration = ARWorldTrackingConfiguration()
        arView.session.run(configuration)
        createSpaceDome(arView)
        let starNode = createStarNode(for: temperature)
        arView.scene.rootNode.addChildNode(starNode)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: Context) {
        // Updates the star's color when the temperature changes
        if let starNode = uiView.scene.rootNode.childNodes.first(where: { $0.name == "star" }) {
            updateStarColor(starNode: starNode, temperature: temperature)
        }
    }
    // Function to create the space dome
    func createSpaceDome(_ arView: ARSCNView) {
        let domeGeometry = SCNSphere(radius: 100)
        let domeMaterial = SCNMaterial()
        domeMaterial.diffuse.contents = UIImage(named: "SpaceBG")
        domeMaterial.isDoubleSided = true
        domeGeometry.materials = [domeMaterial]
        let domeNode = SCNNode(geometry: domeGeometry)
        domeNode.position = SCNVector3(0, 0, 0)
        arView.scene.rootNode.addChildNode(domeNode)
        let light = SCNLight()
        let lightNode = SCNNode()
        lightNode.light = light
        lightNode.position = SCNVector3(x: 0, y: 100, z: 100)
        arView.scene.rootNode.addChildNode(lightNode)
    }
}
func createStarNode(for temperature: Float) -> SCNNode {
    let starGeometry = SCNSphere(radius: 1.0)
    let starNode = SCNNode(geometry: starGeometry)
    let starMaterial = starGeometry.firstMaterial!
    starMaterial.diffuse.contents = UIImage(named: "star_texture.jpg")
    
    updateStarColor(starNode: starNode, temperature: temperature)
    // Adds glowing effect
    starMaterial.emission.contents = starMaterial.diffuse.contents
    starMaterial.emission.intensity = 1.0
    // Adds a subtle shimmer effect
    let pulseAction = SCNAction.repeatForever(SCNAction.sequence([
        SCNAction.fadeOpacity(to: 0.9, duration: 0.5),
        SCNAction.fadeOpacity(to: 1.0, duration: 0.5)
    ]))
    starNode.runAction(pulseAction)
    starNode.position = SCNVector3(0, 0, -5)
    starNode.name = "star"
    
    return starNode
}
func updateStarColor(starNode: SCNNode, temperature: Float) {
    let color = getColorForTemperature(temperature)
    if let material = (starNode.geometry as? SCNSphere)?.firstMaterial {
        material.diffuse.contents = UIImage(named: "star_texture.jpg")
        material.emission.contents = color // Changes glow color based on temperature
    }
}
func getColorForTemperature(_ temperature: Float) -> UIColor {
    switch temperature {
    case 10000...:
        return .blue
    case 7000...9999:
        return .white
    case 4000...6999:
        return .yellow
    default:
        return .red
    }
}
struct StarLearningPopups: View {
    @Binding var showPopups: Bool
    @State private var currentPopupIndex = 0
    let popups: [(text: String, buttonText: String)] = [
        ("Have you ever wondered how astronomers measure the temperature of space objects that are hundreds of light years away? Or why all stars aren't actually yellow? If so, you're in the right place! ✨🚀", "Next ➡️"),
        ("💡 Using Light & Spectroscopy\n\nAstronomers analyze the light stars emit using spectroscopy. By splitting the light into a spectrum, they can see which wavelengths are strongest and determine temperature based on that!", "Next ➡️"),
        ("🔵 Color Tells the Temperature\n\nJust like a flame, stars change color with heat:\n• Red stars 🔴 → Cooler (Below 3,500K)\n• Yellow stars 🟡 → Warmer (Like our Sun, ~ 5,500K)\n• Blue stars 🔵 → Hottest (10,000K and above!)", "Next ➡️"),
        ("🌈 The Science Behind It\n\nHotter objects emit more high - energy light (blue), while cooler ones glow with low - energy light (red). This is known as blackbody radiation - a fundamental law of physics!", "Next ➡️"),
        ("📡 Infrared & Ultraviolet Observations\n\nSome stars are so cool they shine mostly in infrared (invisible to our eyes), while superhot stars can emit ultraviolet radiation! Special telescopes help us “see” these hidden temperatures.", "Next ➡️"),
        ("🧑‍🚀 Now, you get to see it for yourself. You're a cosmonaut with high - tech gear in the open space and you can observe a real star change its colour based on the temperature you set it to (using the slider on the bottom of the page). Have fun!", "Send me to space! 🚀")
    ]
    var body: some View {
        VStack {
            Text(popups[currentPopupIndex].text)
                .font(.system(size: 18, weight: .medium))
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                .padding()
            
            Button(action: {
                if currentPopupIndex < popups.count - 1 {
                    currentPopupIndex += 1
                } else {
                    withAnimation {
                        showPopups = false
                    }
                }
            }) {
                Text(popups[currentPopupIndex].buttonText)
                    .font(.headline)
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.purple)
                    .cornerRadius(10)
            }
            .padding(.top, 10)
        }
        .padding()
        .frame(width: 300)
        .background(Color.white.opacity(0.9))
        .cornerRadius(15)
        .shadow(radius: 5)
    }
}
#Preview {
    StarsTempCol()
}
